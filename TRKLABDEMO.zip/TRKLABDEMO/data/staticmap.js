// create a unique, global symbol name
// -----------------------------------

const STATICMAP_KEY = Symbol.for("My.App.Namespace.static.map")

// check if the global object has this symbol
// add it if it does not have the symbol, yet
// ------------------------------------------

let globalSymbols = Object.getOwnPropertySymbols(global)
let hasFoo = (globalSymbols.indexOf(STATICMAP_KEY) > -1)

if (!hasFoo){
    global[STATICMAP_KEY] = {}
}

// define the singleton API
// ------------------------

let singletonSM = {};

Object.defineProperty(singletonSM, "instance", {
    get: function(){
        return global[STATICMAP_KEY]
    }
})

// ensure the API is never changed
// -------------------------------

Object.freeze(singletonSM)

// export the singleton API only
// -----------------------------

module.exports = singletonSM