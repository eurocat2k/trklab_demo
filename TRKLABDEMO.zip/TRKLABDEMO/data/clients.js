module.exports = {
    count: 0,
    clients: []
}